#include "stopwatchPool.hpp"

GlobalStopwatchPool::__StopwatchPool GlobalStopwatchPool::pool;

