#pragma once

#ifdef SINGLE_PREC
typedef float real;
#else
typedef double real;
#endif


